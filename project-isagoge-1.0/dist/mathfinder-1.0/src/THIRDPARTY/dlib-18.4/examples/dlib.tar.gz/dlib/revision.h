#ifndef DLIB_REVISION_H
// Version:  18.4
// Date:     Wed Aug 28 18:46:59 EDT 2013
// Mercurial Revision ID:  78be73b57b82
#define DLIB_MAJOR_VERSION  18
#define DLIB_MINOR_VERSION  4
#endif
