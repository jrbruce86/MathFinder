// Copyright (C) 2012  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_BSP__
#define DLIB_BSP__ 


#include "bsp/bsp.h"

#endif // DLIB_BSP__ 



