// Copyright (C) 2012  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_VECTORSTReAM__
#define DLIB_VECTORSTReAM__

#include "vectorstream/vectorstream.h"


#endif // DLIB_VECTORSTReAM__

